import { spawnSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";

const extractedRoot = path.resolve(process.argv[2] || "");
const resultPath = process.argv[3] ? path.resolve(process.argv[3]) : null;
const rgCommand = process.argv[4] || "rg";

if (!process.argv[2]) {
  throw new Error(
    "Usage: node patch-fast-ui.mjs <extracted-app-root> [result-json] [rg-command]",
  );
}

const assetsRoot = path.join(extractedRoot, "webview", "assets");
if (!fs.existsSync(assetsRoot)) {
  throw new Error(`Missing webview assets directory: ${assetsRoot}`);
}

// `webview/assets` holds thousands of files and install.ps1 runs from a long temp path, so the
// listing outgrows the 1 MB spawnSync default: on Codex 26.814.5167.0 it reached 1.11 MB and
// spawnSync aborted with ENOBUFS before the gate below was ever inspected.
const result = spawnSync(rgCommand, ["--files", assetsRoot], {
  encoding: "utf8",
  windowsHide: true,
  maxBuffer: 256 * 1024 * 1024,
});
if (result.error || result.status !== 0) {
  const reason =
    result.error?.code ||
    result.error?.message ||
    result.stderr ||
    result.stdout ||
    "unknown error";
  throw new Error(`rg --files failed (status ${result.status}): ${reason}`);
}

// Codex 26.903 / 26.908 moved the consumers of `isServiceTierAllowed` into app-primary-<hash>.js;
// the gate itself still lives in app-initial-<hash>.js. Keep the newer chunk in the candidate
// set so a future move is still found — the exactly-one-occurrence rule below stays the guard.
const candidates = result.stdout
  .split(/\r?\n/)
  .map((value) => value.trim())
  .filter(Boolean)
  .filter((file) =>
    /(?:app-initial|app-primary|use-service-tier-settings|use-is-fast-mode-enabled|general-settings)-.*\.js$/i.test(
      file.replaceAll("\\", "/"),
    ),
  );

const variants = [
  "d=a&&!u&&c!=null&&c?.requirements?.featureRequirements?.fast_mode!==!1,f;",
  "d=a&&!u&&(o===`apikey`||c!=null&&c?.requirements?.featureRequirements?.fast_mode!==!1),f;",
];
const patchedMarker = "d=!0,f;";
const originals = [];
const patched = [];

for (const file of candidates) {
  const source = fs.readFileSync(file, "utf8");
  for (const before of variants) {
    const count = countOccurrences(source, before);
    if (count > 0) originals.push({ file, before, count, source });
  }
  const patchedCount = countOccurrences(source, patchedMarker);
  if (patchedCount > 0) patched.push({ file, count: patchedCount });
}

const originalCount = originals.reduce((sum, item) => sum + item.count, 0);
const patchedCount = patched.reduce((sum, item) => sum + item.count, 0);
let status;
let targetFile;

if (originalCount === 1 && patchedCount === 0) {
  const match = originals.find((item) => item.count === 1);
  fs.writeFileSync(
    match.file,
    match.source.replace(match.before, patchedMarker),
    "utf8",
  );
  status = "patched";
  targetFile = match.file;
} else if (originalCount === 0 && patchedCount === 1) {
  status = "already-patched";
  targetFile = patched.find((item) => item.count === 1).file;
} else {
  throw new Error(
    `Expected one original or patched Fast UI gate, found originals=${originalCount}, patched=${patchedCount}. This Codex build is not supported.`,
  );
}

const relativeFile = path.relative(extractedRoot, targetFile).replaceAll("\\", "/");
const output = {
  toolkitVersion: "2026.09.12-minimal",
  status,
  modifiedFiles: status === "patched" ? [relativeFile] : [],
  targetFile: relativeFile,
  change: "Force isServiceTierAllowed to true",
};

if (resultPath) {
  fs.writeFileSync(resultPath, `${JSON.stringify(output, null, 2)}\n`, "utf8");
}

console.log(`${status}: Fast UI gate (${relativeFile})`);

function countOccurrences(source, needle) {
  let count = 0;
  let offset = 0;
  while ((offset = source.indexOf(needle, offset)) !== -1) {
    count += 1;
    offset += needle.length;
  }
  return count;
}

# Codex Fast UI Minimal

这是仅启用 Fast UI 的最小 Windows 补丁工具包。

它不会修改插件页、不会创建 marketplace、不会复制插件 bundle、不会读取或保存账号 token。

## 唯一功能补丁

工具包使用 `rg` 动态查找当前 Codex build 中带 hash 的 service tier JavaScript 文件，然后只把 `isServiceTierAllowed` 的最终 gate 改为 `true`。

当前已测试 build 中，实际变更等价于：

```js
d = a && !u && c != null && c?.requirements?.featureRequirements?.fast_mode !== false;
```

改为：

```js
d = true;
```

压缩后的真实代码只替换一个表达式。原生 `serviceTier` 设置、`thread/start`、当前任务下一轮设置和 Codex CLI 请求流程均保持不变。

选择 Fast 时，原生 UI 使用 `priority` service tier；选择 Standard 时恢复默认 tier。上游 API、代理服务和模型必须真正支持 Priority/Fast，否则可能忽略该字段或返回错误。

## 不包含

- OpenAI 官方 Codex 应用程序
- 修改后的完整 `app.asar`
- curated 插件补丁
- marketplace 或插件同步器
- token 或账号配置

## 已测试版本

- Windows AppX（离线 MSIX `ChatGPT-x64.msix`）：`OpenAI.Codex 26.903.8094.0 x64`
  - 应用内部版本：`26.903.61454`，build `8378`
- Windows AppX（Microsoft Store / 应用内自动更新）：`OpenAI.Codex 26.908.4834.0 x64`
  - 应用内部版本：`26.908.40834`，build `8881`
- 工具包：`2026.09.12-minimal`（基于 `2026.08.19-minimal`，改动见下）

## 本地修改（SeedRouter）

### 2026.08.19

`patch-fast-ui.mjs` 用 `spawnSync` 调 `rg --files` 列举 `webview/assets`，此前没有设置
`maxBuffer`，沿用 Node 默认的 1 MB。Codex `26.814.5167.0` 的该目录下有 7598 个文件，加上
`install.ps1` 运行时所在的临时目录路径长度，输出约 1.11 MB，越过上限后 `spawnSync` 以
`ENOBUFS` 中止——补丁在检查 gate 之前就失败了。现在显式指定 `maxBuffer`，并在报错信息里带上
`error.code`（此前只显示 `status`，而它在这种情况下是 `null`）。补丁逻辑本身未改动：
`26.814.5167.0` 上 gate 仍然恰好出现一次，仍由同一处替换生效。

### 2026.09.12

针对 Codex `26.903.8094.0`（离线 MSIX）与 `26.908.4834.0`（Store / 自动更新）重新打包。这两个
build 把 `isServiceTierAllowed` 的调用方移进了 `webview/assets/app-primary-<hash>.js`，但 gate
表达式本身仍在 `app-initial-<hash>.js` 里，逐文件扫描确认它在两个 build 中都恰好出现一次（已打补丁
的标记 `d=!0,f;` 出现 0 次）。补丁逻辑因此没有改动，唯一的代码改动是把候选文件名正则扩展到
`app-primary-*.js`，将来 gate 若迁入该 chunk 也能被找到——真正的保护仍是「恰好出现一次」这条规则，
不满足时补丁器照旧停止。

同时修复了 `verify.ps1` 与 `restore.ps1`：二者原本在 `param()` 默认值里用
`$MyInvocation.MyCommand.Path` 推断脚本所在目录，但脚本声明了 `[CmdletBinding()]`，Windows
PowerShell 5.1 在求默认值时 `$MyInvocation.MyCommand.Path`（以及 `$PSScriptRoot`）为空，以
`powershell.exe -File verify.ps1` 不带 `-Root` 运行会在 `Split-Path` 处立即报错
（`Cannot bind argument to parameter 'Path' because it is null`）——SeedRouter 接入引导工具正是
这样调用它们的。现在 `-Root` 默认为空，在脚本正文里回退到 `$PSScriptRoot`；显式传入 `-Root` 时行为
不变。`tools/`、`LICENSE`、`THIRD_PARTY_NOTICES.md` 与 `2026.08.19-minimal` 完全相同。

新版 Codex 如果压缩代码发生变化，补丁器会停止，不会猜测性修改。

## 安装

先安装并至少运行一次官方 Codex Windows 应用，然后完全退出已有的 Codex Fast UI 副本。

在工具包目录运行：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\install.ps1
```

默认输出目录：

```text
%USERPROFILE%\Downloads\Report\CodexFastUI
```

启动入口：

```text
CodexFastUI\Codex Fast UI.lnk
```

脚本会复制用户自己的官方应用、解包并重打包副本的 `app.asar`，不会修改 `WindowsApps`。独立副本使用 `CodexFastUI` 用户数据目录，因此可以与系统版同时运行。

需要 Node.js `22.12` 或更高版本。脚本会优先使用 Codex primary runtime 自带的 Node.js。ASAR 工具已经包含在包内，`rg.exe` 使用官方 Codex 应用自带的副本。

已有输出目录时：

```powershell
.\install.ps1 -Force
```

安装后立即启动：

```powershell
.\install.ps1 -Launch
```

## 验证

```powershell
& "$env:USERPROFILE\Downloads\Report\CodexFastUI\verify.ps1"
```

验证脚本会重新解包 ASAR，确认唯一 Fast UI gate 已修改，并对目标 JavaScript 执行 `node --check`。

## 恢复

完全退出 Codex Fast UI 后运行：

```powershell
& "$env:USERPROFILE\Downloads\Report\CodexFastUI\restore.ps1"
```

这只恢复独立副本的官方 ASAR。系统安装版从未被修改。

## 说明

这不是源码重编译，也不是 Codex 插件。它是针对官方 Electron 应用副本的单点 ASAR 前端补丁。快捷方式必须指向 `app\ChatGPT.exe`，不能指向辅助程序 `app\Codex.exe`。

[CmdletBinding()]
param(
    [string]$Root = ''
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

# Resolved here rather than in the param default: under [CmdletBinding()] Windows PowerShell 5.1
# leaves $MyInvocation.MyCommand.Path (and $PSScriptRoot) empty while defaults are evaluated, so
# `powershell.exe -File verify.ps1` without -Root failed in Split-Path before checking anything.
if ([string]::IsNullOrWhiteSpace($Root)) {
    $Root = $PSScriptRoot
}
$Root = [IO.Path]::GetFullPath($Root)
$app = Join-Path $Root 'app'
$resources = Join-Path $app 'resources'
$asar = Join-Path $resources 'app.asar'
$rg = Join-Path $resources 'rg.exe'
$asarCli = Join-Path $Root 'tools\asar-tool\node_modules\@electron\asar\bin\asar.mjs'
$patchScript = Join-Path $Root 'patch-fast-ui.mjs'

function Get-NodePath {
    $bundled = Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'
    if (Test-Path -LiteralPath $bundled) { return $bundled }
    $command = Get-Command node -ErrorAction SilentlyContinue
    if ($null -ne $command) { return $command.Source }
    throw 'Node.js 22.12 or newer was not found.'
}

function Invoke-Checked {
    param([string]$FilePath, [string[]]$Arguments)
    & $FilePath @Arguments
    if ($LASTEXITCODE -ne 0) {
        throw "Command failed with exit code $LASTEXITCODE`: $FilePath"
    }
}

function Remove-DirectoryWithNode {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) { return }
    Invoke-Checked -FilePath $node -Arguments @(
        '-e',
        'process.getBuiltinModule(String.fromCharCode(102,115)).rmSync(process.argv[1],{recursive:true,force:true,maxRetries:3})',
        $Path
    )
}

foreach ($required in @(
    (Join-Path $app 'ChatGPT.exe'),
    $asar,
    $rg,
    $asarCli,
    $patchScript,
    (Join-Path $Root 'Codex Fast UI.lnk')
)) {
    if (-not (Test-Path -LiteralPath $required)) {
        throw "Missing required file: $required"
    }
}

$ini = Get-Content -Raw -LiteralPath (Join-Path $resources 'owl-app.ini')
if ($ini -notmatch '(?m)^UserDataDirectoryName=CodexFastUI\s*$') {
    throw 'owl-app.ini does not use the isolated CodexFastUI profile.'
}

$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut((Join-Path $Root 'Codex Fast UI.lnk'))
$expectedTarget = [IO.Path]::GetFullPath((Join-Path $app 'ChatGPT.exe'))
if (-not $shortcut.TargetPath.Equals($expectedTarget, [StringComparison]::OrdinalIgnoreCase)) {
    throw "Shortcut target is incorrect: $($shortcut.TargetPath)"
}

$node = Get-NodePath
$tempRoot = Join-Path ([IO.Path]::GetTempPath()) ("codex-fast-ui-verify-" + [Guid]::NewGuid().ToString('N'))
$extracted = Join-Path $tempRoot 'extracted'
$resultPath = Join-Path $tempRoot 'patch-result.json'
New-Item -ItemType Directory -Force -Path $tempRoot | Out-Null

try {
    Invoke-Checked -FilePath $node -Arguments @($asarCli, 'extract', $asar, $extracted)
    Invoke-Checked -FilePath $node -Arguments @($patchScript, $extracted, $resultPath, $rg)
    $result = Get-Content -Raw -LiteralPath $resultPath | ConvertFrom-Json
    if ([string]$result.status -ne 'already-patched') {
        throw 'The installed ASAR did not contain the expected Fast UI patch marker.'
    }
    $target = Join-Path $extracted ([string]$result.targetFile).Replace('/', '\')
    Invoke-Checked -FilePath $node -Arguments @('--check', $target)
}
finally {
    if (Test-Path -LiteralPath $tempRoot) {
        try { Remove-DirectoryWithNode -Path $tempRoot }
        catch { Write-Warning "Could not remove temporary directory: $tempRoot" }
    }
}

Write-Host 'Fast UI gate: OK'
Write-Host 'JavaScript syntax: OK'
Write-Host 'Isolated profile: OK'
Write-Host 'Shortcut target: OK'
Write-Host 'No plugin or marketplace verification is included in this minimal build.'

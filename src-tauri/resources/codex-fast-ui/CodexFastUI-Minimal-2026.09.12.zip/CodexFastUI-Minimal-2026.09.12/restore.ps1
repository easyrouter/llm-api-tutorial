[CmdletBinding()]
param(
    [string]$Root = '',
    [string]$BackupRoot = ''
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

# Resolved here rather than in the param default: under [CmdletBinding()] Windows PowerShell 5.1
# leaves $MyInvocation.MyCommand.Path (and $PSScriptRoot) empty while defaults are evaluated, so
# `powershell.exe -File restore.ps1` without -Root failed in Split-Path before restoring anything.
if ([string]::IsNullOrWhiteSpace($Root)) {
    $Root = $PSScriptRoot
}
$Root = [IO.Path]::GetFullPath($Root)
$targetApp = Join-Path $Root 'app'
$targetResources = Join-Path $targetApp 'resources'
$targetAsar = Join-Path $targetResources 'app.asar'
$targetUnpacked = Join-Path $targetResources 'app.asar.unpacked'

function Get-NodePath {
    $bundled = Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'
    if (Test-Path -LiteralPath $bundled) { return $bundled }
    $command = Get-Command node -ErrorAction SilentlyContinue
    if ($null -ne $command) { return $command.Source }
    throw 'Node.js 22.12 or newer was not found.'
}

function Remove-DirectoryWithNode {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) { return }
    & $node -e 'process.getBuiltinModule(String.fromCharCode(102,115)).rmSync(process.argv[1],{recursive:true,force:true,maxRetries:3})' $Path
    if ($LASTEXITCODE -ne 0) {
        throw "Could not remove directory: $Path"
    }
}

$prefix = ([IO.Path]::GetFullPath($targetApp)).TrimEnd('\') + '\'
$running = Get-Process -Name ChatGPT -ErrorAction SilentlyContinue |
    Where-Object { $null -ne $_.Path -and $_.Path.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase) }
if ($running) {
    throw 'Codex Fast UI is running. Completely exit it, including the tray process, then rerun restore.ps1.'
}

if ([string]::IsNullOrWhiteSpace($BackupRoot)) {
    $installRecord = Join-Path $Root 'patch-install.json'
    if (Test-Path -LiteralPath $installRecord) {
        $record = Get-Content -Raw -LiteralPath $installRecord | ConvertFrom-Json
        if ($null -ne $record.backupRoot -and (Test-Path -LiteralPath ([string]$record.backupRoot))) {
            $BackupRoot = [string]$record.backupRoot
        }
    }
}

if ([string]::IsNullOrWhiteSpace($BackupRoot)) {
    $latest = Get-ChildItem -LiteralPath (Join-Path $Root 'backups') -Directory -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -like 'official-before-patch-*' } |
        Sort-Object LastWriteTime -Descending |
        Select-Object -First 1
    if ($null -ne $latest) { $BackupRoot = $latest.FullName }
}

if ([string]::IsNullOrWhiteSpace($BackupRoot)) {
    throw 'No official-before-patch backup was found.'
}

$BackupRoot = [IO.Path]::GetFullPath($BackupRoot)
$node = Get-NodePath
$backupAsar = Join-Path $BackupRoot 'app.asar'
$backupUnpacked = Join-Path $BackupRoot 'app.asar.unpacked'
if (-not (Test-Path -LiteralPath $backupAsar)) {
    throw "Backup app.asar not found: $backupAsar"
}

Copy-Item -Force -LiteralPath $backupAsar -Destination $targetAsar
if (Test-Path -LiteralPath $backupUnpacked) {
    if (Test-Path -LiteralPath $targetUnpacked) {
        Remove-DirectoryWithNode -Path $targetUnpacked
    }
    New-Item -ItemType Directory -Force -Path $targetUnpacked | Out-Null
    & robocopy.exe $backupUnpacked $targetUnpacked /E /COPY:DAT /DCOPY:DAT /R:2 /W:1 /NFL /NDL /NJH /NJS /NP
    if ($LASTEXITCODE -gt 7) {
        throw "robocopy failed with exit code $LASTEXITCODE"
    }
}

Write-Host "Restored official ASAR from: $BackupRoot"
Write-Host 'The system-installed Codex app was never modified.'

[CmdletBinding()]
param(
    [string]$OutputRoot = (Join-Path $env:USERPROFILE 'Downloads\Report\CodexFastUI'),
    [string]$SourceRoot = '',
    [switch]$Force,
    [switch]$Launch
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$toolkitRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$OutputRoot = [IO.Path]::GetFullPath($OutputRoot)

function Get-SourceAppPath {
    param([string]$RequestedRoot)

    if (-not [string]::IsNullOrWhiteSpace($RequestedRoot)) {
        $candidate = [IO.Path]::GetFullPath($RequestedRoot)
        if (Test-Path -LiteralPath (Join-Path $candidate 'ChatGPT.exe')) {
            return $candidate
        }
        if (Test-Path -LiteralPath (Join-Path $candidate 'app\ChatGPT.exe')) {
            return (Join-Path $candidate 'app')
        }
        throw "SourceRoot does not contain app\ChatGPT.exe: $candidate"
    }

    $package = Get-AppxPackage -Name 'OpenAI.Codex' -ErrorAction SilentlyContinue |
        Sort-Object Version -Descending |
        Select-Object -First 1
    if ($null -eq $package) {
        throw 'The official OpenAI Codex Windows app is not installed for this user.'
    }

    $candidate = Join-Path $package.InstallLocation 'app'
    if (-not (Test-Path -LiteralPath (Join-Path $candidate 'ChatGPT.exe'))) {
        throw "Could not find the official Codex app directory: $candidate"
    }
    return $candidate
}

function Get-NodePath {
    $bundled = Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'
    if (Test-Path -LiteralPath $bundled) {
        return $bundled
    }

    $command = Get-Command node -ErrorAction SilentlyContinue
    if ($null -ne $command) {
        return $command.Source
    }

    throw 'Node.js 22.12 or newer was not found. Install Node.js, or let Codex install its primary runtime, then rerun this script.'
}

function Invoke-Checked {
    param(
        [Parameter(Mandatory = $true)][string]$FilePath,
        [Parameter(Mandatory = $true)][string[]]$Arguments
    )

    & $FilePath @Arguments
    if ($LASTEXITCODE -ne 0) {
        throw "Command failed with exit code $LASTEXITCODE`: $FilePath"
    }
}

function Remove-DirectoryWithNode {
    param([string]$Path)

    if (-not (Test-Path -LiteralPath $Path)) { return }
    Invoke-Checked -FilePath $node -Arguments @(
        '-e',
        'process.getBuiltinModule(String.fromCharCode(102,115)).rmSync(process.argv[1],{recursive:true,force:true,maxRetries:3})',
        $Path
    )
}

function Assert-NotRunning {
    param([string]$TargetApp)

    $prefix = ([IO.Path]::GetFullPath($TargetApp)).TrimEnd('\') + '\'
    $running = Get-Process -Name ChatGPT -ErrorAction SilentlyContinue |
        Where-Object { $null -ne $_.Path -and $_.Path.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase) }
    if ($running) {
        throw 'Codex Fast UI is running. Completely exit it, including the tray process, then rerun this script.'
    }
}

function Copy-DirectoryChecked {
    param([string]$Source, [string]$Destination)

    New-Item -ItemType Directory -Force -Path $Destination | Out-Null
    & robocopy.exe $Source $Destination /E /COPY:DAT /DCOPY:DAT /R:2 /W:1 /NFL /NDL /NJH /NJS /NP
    if ($LASTEXITCODE -gt 7) {
        throw "robocopy failed with exit code $LASTEXITCODE"
    }
}

$sourceApp = Get-SourceAppPath -RequestedRoot $SourceRoot
$sourceApp = [IO.Path]::GetFullPath($sourceApp)
$sourceAsar = Join-Path $sourceApp 'resources\app.asar'
$sourceRg = Join-Path $sourceApp 'resources\rg.exe'

if (-not (Test-Path -LiteralPath $sourceAsar)) {
    throw "Missing source app.asar: $sourceAsar"
}
if (-not (Test-Path -LiteralPath $sourceRg)) {
    throw "Missing source rg.exe: $sourceRg"
}
if ($OutputRoot.StartsWith($sourceApp, [StringComparison]::OrdinalIgnoreCase)) {
    throw 'OutputRoot must not be inside the official application directory.'
}
if ($OutputRoot -match '(?i)\\WindowsApps(?:\\|$)') {
    throw 'OutputRoot must not be inside WindowsApps.'
}

$node = Get-NodePath
$asarCli = Join-Path $toolkitRoot 'tools\asar-tool\node_modules\@electron\asar\bin\asar.mjs'
$patchScript = Join-Path $toolkitRoot 'patch-fast-ui.mjs'
if (-not (Test-Path -LiteralPath $asarCli)) {
    throw "Missing bundled ASAR tool: $asarCli"
}

$targetApp = Join-Path $OutputRoot 'app'
Assert-NotRunning -TargetApp $targetApp

New-Item -ItemType Directory -Force -Path $OutputRoot | Out-Null
if (Test-Path -LiteralPath $targetApp) {
    if (-not $Force) {
        throw "Target app already exists: $targetApp. Rerun with -Force after completely exiting Codex Patched."
    }
    $previousApp = Join-Path $OutputRoot "backups\app-before-install-$timestamp"
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $previousApp) | Out-Null
    Move-Item -LiteralPath $targetApp -Destination $previousApp
    Write-Host "Previous patched app moved to: $previousApp"
}

Write-Host "Copying official Codex app from: $sourceApp"
Copy-DirectoryChecked -Source $sourceApp -Destination $targetApp

$targetResources = Join-Path $targetApp 'resources'
$targetAsar = Join-Path $targetResources 'app.asar'
$targetUnpacked = Join-Path $targetResources 'app.asar.unpacked'
$backupRoot = Join-Path $OutputRoot "backups\official-before-patch-$timestamp"
New-Item -ItemType Directory -Force -Path $backupRoot | Out-Null
Copy-Item -LiteralPath $targetAsar -Destination (Join-Path $backupRoot 'app.asar')
if (Test-Path -LiteralPath $targetUnpacked) {
    Copy-DirectoryChecked -Source $targetUnpacked -Destination (Join-Path $backupRoot 'app.asar.unpacked')
}

$tempRoot = Join-Path ([IO.Path]::GetTempPath()) ("codex-patched-toolkit-" + [Guid]::NewGuid().ToString('N'))
$extractedRoot = Join-Path $tempRoot 'extracted'
$patchedAsar = Join-Path $tempRoot 'app.asar'
$patchedUnpacked = "$patchedAsar.unpacked"
$patchResult = Join-Path $tempRoot 'patch-result.json'

New-Item -ItemType Directory -Force -Path $tempRoot | Out-Null
try {
    Write-Host 'Extracting app.asar...'
    Invoke-Checked -FilePath $node -Arguments @($asarCli, 'extract', $targetAsar, $extractedRoot)

    Write-Host 'Applying the single Fast UI gate patch...'
    $targetRg = Join-Path $targetResources 'rg.exe'
    Invoke-Checked -FilePath $node -Arguments @($patchScript, $extractedRoot, $patchResult, $targetRg)

    $result = Get-Content -Raw -LiteralPath $patchResult | ConvertFrom-Json
    foreach ($relativePath in @($result.modifiedFiles)) {
        $file = Join-Path $extractedRoot ([string]$relativePath).Replace('/', '\')
        Invoke-Checked -FilePath $node -Arguments @('--check', $file)
    }

    Write-Host 'Repacking app.asar...'
    $unpackDirectories = 'node_modules/{@worklouder/device-kit-oai,better-sqlite3,node-pty}'
    Invoke-Checked -FilePath $node -Arguments @(
        $asarCli,
        'pack',
        '--unpack-dir',
        $unpackDirectories,
        $extractedRoot,
        $patchedAsar
    )

    Copy-Item -Force -LiteralPath $patchedAsar -Destination $targetAsar
    if (Test-Path -LiteralPath $patchedUnpacked) {
        if (Test-Path -LiteralPath $targetUnpacked) {
            Remove-DirectoryWithNode -Path $targetUnpacked
        }
        Copy-DirectoryChecked -Source $patchedUnpacked -Destination $targetUnpacked
    }

    $installedResult = [ordered]@{
        toolkitVersion = '2026.07.30-minimal'
        installedAt = (Get-Date).ToString('o')
        sourceApp = $sourceApp
        sourceAsarSha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $sourceAsar).Hash
        patchedAsarSha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $targetAsar).Hash
        backupRoot = $backupRoot
        modifiedFiles = @($result.modifiedFiles)
        patchStatus = [string]$result.status
        targetFile = [string]$result.targetFile
        change = [string]$result.change
    }
    $installedResult | ConvertTo-Json -Depth 8 |
        Set-Content -LiteralPath (Join-Path $OutputRoot 'patch-install.json') -Encoding UTF8
}
finally {
    if (Test-Path -LiteralPath $tempRoot) {
        try {
            Remove-DirectoryWithNode -Path $tempRoot
        }
        catch {
            Write-Warning "Could not remove temporary directory: $tempRoot"
        }
    }
}

$owlIni = Join-Path $targetResources 'owl-app.ini'
@('[Owl]', 'UserDataDirectoryName=CodexFastUI') |
    Set-Content -LiteralPath $owlIni -Encoding ASCII

$supportFiles = @(
    'README.zh-CN.md',
    'verify.ps1',
    'restore.ps1',
    'THIRD_PARTY_NOTICES.md'
)
foreach ($name in $supportFiles) {
    Copy-Item -Force -LiteralPath (Join-Path $toolkitRoot $name) -Destination (Join-Path $OutputRoot $name)
}
Copy-Item -Force -LiteralPath $patchScript -Destination (Join-Path $OutputRoot 'patch-fast-ui.mjs')
Copy-DirectoryChecked -Source (Join-Path $toolkitRoot 'tools') -Destination (Join-Path $OutputRoot 'tools')

$shortcutPath = Join-Path $OutputRoot 'Codex Fast UI.lnk'
$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut($shortcutPath)
$shortcut.TargetPath = Join-Path $targetApp 'ChatGPT.exe'
$shortcut.WorkingDirectory = $targetApp
$shortcut.Description = 'Independent Codex app with the Fast UI gate enabled'
$shortcut.Save()

Write-Host ''
Write-Host "Installed: $OutputRoot"
Write-Host "Shortcut: $shortcutPath"
Write-Host 'Completely exit Codex Fast UI before replacing or updating its app.asar.'

if ($Launch) {
    Start-Process -FilePath $shortcutPath
}

# Third-party notices

## codex-openfast

The single Fast UI gate approach was adapted for the tested Windows Codex build from the public project:

```text
https://github.com/congwa/codex-openfast
```

## @electron/asar

This toolkit vendors `@electron/asar` version `4.2.1` and its runtime dependencies under their respective licenses. License files are retained under `tools/asar-tool/node_modules`.

## OpenAI Codex

OpenAI Codex is not included. The installer copies the official application already installed for the current Windows user. OpenAI product names and trademarks belong to their respective owner.

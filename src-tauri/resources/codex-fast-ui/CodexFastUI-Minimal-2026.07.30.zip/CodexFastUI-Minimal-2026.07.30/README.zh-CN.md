# Codex Fast UI Minimal

这是仅启用 Fast UI 的最小 Windows 补丁工具包。

它不会修改插件页、不会创建 marketplace、不会复制插件 bundle、不会读取或保存账号 token。

## 唯一功能补丁

工具包使用 `rg` 动态查找当前 Codex build 中带 hash 的 service tier JavaScript 文件，然后只把 `isServiceTierAllowed` 的最终 gate 改为 `true`。

当前已测试 build 中，实际变更等价于：

```js
d = a && !u && c != null && c?.requirements?.featureRequirements?.fast_mode !== false;
```

改为：

```js
d = true;
```

压缩后的真实代码只替换一个表达式。原生 `serviceTier` 设置、`thread/start`、当前任务下一轮设置和 Codex CLI 请求流程均保持不变。

选择 Fast 时，原生 UI 使用 `priority` service tier；选择 Standard 时恢复默认 tier。上游 API、代理服务和模型必须真正支持 Priority/Fast，否则可能忽略该字段或返回错误。

## 不包含

- OpenAI 官方 Codex 应用程序
- 修改后的完整 `app.asar`
- curated 插件补丁
- marketplace 或插件同步器
- token 或账号配置

## 已测试版本

- Windows AppX：`OpenAI.Codex 26.721.11231.0 x64`
- 应用内部版本：`26.721.81911`，build `5973`
- 工具包：`2026.07.30-minimal`

新版 Codex 如果压缩代码发生变化，补丁器会停止，不会猜测性修改。

## 安装

先安装并至少运行一次官方 Codex Windows 应用，然后完全退出已有的 Codex Fast UI 副本。

在工具包目录运行：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\install.ps1
```

默认输出目录：

```text
%USERPROFILE%\Downloads\Report\CodexFastUI
```

启动入口：

```text
CodexFastUI\Codex Fast UI.lnk
```

脚本会复制用户自己的官方应用、解包并重打包副本的 `app.asar`，不会修改 `WindowsApps`。独立副本使用 `CodexFastUI` 用户数据目录，因此可以与系统版同时运行。

需要 Node.js `22.12` 或更高版本。脚本会优先使用 Codex primary runtime 自带的 Node.js。ASAR 工具已经包含在包内，`rg.exe` 使用官方 Codex 应用自带的副本。

已有输出目录时：

```powershell
.\install.ps1 -Force
```

安装后立即启动：

```powershell
.\install.ps1 -Launch
```

## 验证

```powershell
& "$env:USERPROFILE\Downloads\Report\CodexFastUI\verify.ps1"
```

验证脚本会重新解包 ASAR，确认唯一 Fast UI gate 已修改，并对目标 JavaScript 执行 `node --check`。

## 恢复

完全退出 Codex Fast UI 后运行：

```powershell
& "$env:USERPROFILE\Downloads\Report\CodexFastUI\restore.ps1"
```

这只恢复独立副本的官方 ASAR。系统安装版从未被修改。

## 说明

这不是源码重编译，也不是 Codex 插件。它是针对官方 Electron 应用副本的单点 ASAR 前端补丁。快捷方式必须指向 `app\ChatGPT.exe`，不能指向辅助程序 `app\Codex.exe`。
